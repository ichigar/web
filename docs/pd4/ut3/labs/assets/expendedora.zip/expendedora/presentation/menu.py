from expendedora.infrastructure.datos_iniciales import crear_servicio


def mostrar_menu():
    """Muestra las opciones de la maquina."""
    print("\n=== MAQUINA EXPENDEDORA ===")
    print("1. Mostrar productos")
    print("2. Seleccionar producto")
    print("3. Insertar dinero")
    print("4. Comprar")
    print("5. Cancelar")
    print("6. Reponer")
    print("7. Agregar producto")
    print("8. Agregar producto con descuento")
    print("9. Salir")


def opcion_mostrar(servicio):
    """Muestra el catalogo de productos disponibles."""
    productos = servicio.listar_productos()
    if not productos:
        print("(No hay productos)")
    else:
        for codigo, nombre, precio_base, precio_final, cantidad, porcentaje_descuento in productos:
            if porcentaje_descuento > 0:
                print(f"{codigo} - {nombre} - {precio_final:.2f} EUR (antes {precio_base:.2f}, -{porcentaje_descuento:.0f}%) - stock {cantidad}")
            else:
                print(f"{codigo} - {nombre} - {precio_base:.2f} EUR - stock {cantidad}")


def opcion_seleccionar(servicio):
    """Pide un codigo al usuario y selecciona el producto."""
    codigo = input("Codigo: ").strip().upper()
    servicio.seleccionar(codigo)
    print("Producto seleccionado.")


def opcion_insertar(servicio):
    """Pide una cantidad al usuario e inserta dinero en la maquina."""
    try:
        cantidad = float(input("Cantidad a insertar: ").strip())
    except ValueError:
        raise ValueError("Introduce un numero valido.")
    servicio.insertar_dinero(cantidad)
    print("Saldo actualizado.")


def opcion_comprar(servicio):
    """Ejecuta la compra del producto seleccionado y muestra el cambio."""
    cambio = servicio.comprar()
    print(f"Compra realizada. Cambio: {cambio:.2f} EUR")


def opcion_cancelar(servicio):
    """Cancela la operacion y devuelve el saldo al usuario."""
    devuelto = servicio.cancelar()
    print(f"Operacion cancelada. Devuelto: {devuelto:.2f} EUR")


def opcion_reponer(servicio):
    """Pide codigo y unidades al usuario y repone el stock del producto."""
    codigo = input("Codigo: ").strip().upper()
    try:
        unidades = int(input("Unidades a reponer: ").strip())
    except ValueError:
        raise ValueError("Introduce un numero entero valido.")
    servicio.reponer(codigo, unidades)
    print("Stock actualizado.")


def opcion_agregar_producto(servicio):
    """Pide datos al usuario y agrega un producto sin descuento."""
    codigo = input("Codigo: ").strip().upper()
    nombre = input("Nombre: ").strip()
    try:
        precio = float(input("Precio: ").strip())
    except ValueError:
        raise ValueError("El precio debe ser un numero valido.")
    try:
        cantidad = int(input("Cantidad: ").strip())
    except ValueError:
        raise ValueError("La cantidad debe ser un numero entero valido.")
    servicio.agregar_producto(codigo, nombre, precio, cantidad)
    print("Producto agregado.")


def opcion_agregar_producto_con_descuento(servicio):
    """Pide datos al usuario y agrega un producto con descuento."""
    codigo = input("Codigo: ").strip().upper()
    nombre = input("Nombre: ").strip()
    try:
        precio = float(input("Precio: ").strip())
    except ValueError:
        raise ValueError("El precio debe ser un numero valido.")
    try:
        cantidad = int(input("Cantidad: ").strip())
    except ValueError:
        raise ValueError("La cantidad debe ser un numero entero valido.")
    try:
        porcentaje = float(input("Porcentaje descuento: ").strip())
    except ValueError:
        raise ValueError("El porcentaje debe ser un numero valido.")
    servicio.agregar_producto_con_descuento(codigo, nombre, precio, cantidad, porcentaje)
    print("Producto con descuento agregado.")


def main():
    """Bucle principal de la maquina expendedora."""
    servicio = crear_servicio()
    while True:
        mostrar_menu()
        opcion = input("Elige una opcion: ").strip()
        try:
            if opcion == "1":
                opcion_mostrar(servicio)
            elif opcion == "2":
                opcion_seleccionar(servicio)
            elif opcion == "3":
                opcion_insertar(servicio)
            elif opcion == "4":
                opcion_comprar(servicio)
            elif opcion == "5":
                opcion_cancelar(servicio)
            elif opcion == "6":
                opcion_reponer(servicio)
            elif opcion == "7":
                opcion_agregar_producto(servicio)
            elif opcion == "8":
                opcion_agregar_producto_con_descuento(servicio)
            elif opcion == "9":
                print("Hasta luego.")
                break
            else:
                print("Opcion no valida.")
        except ValueError as e:
            print("X " + str(e))


if __name__ == "__main__":
    main()
