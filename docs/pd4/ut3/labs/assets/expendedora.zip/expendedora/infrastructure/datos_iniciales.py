"""Infraestructura: datos iniciales para demos y pruebas."""

from expendedora.domain.item import Item, ItemConDescuento
from expendedora.infrastructure.repositorio_memoria import RepositorioProductosMemoria


def crear_repositorio_con_datos():
    """Crea un repositorio en memoria con productos precargados."""
    repo = RepositorioProductosMemoria()
    # Datos base para demos: permiten probar compra y descuentos.
    repo.guardar(Item("A1", "Agua", 1.00, 10))
    repo.guardar(Item("A2", "Papas", 1.50, 8))
    repo.guardar(ItemConDescuento("D1", "Refresco", 2.50, 5, 20))
    return repo


def crear_servicio():
    """Crea y devuelve un ServicioExpendedora listo para usar."""
    from expendedora.domain.maquina import MaquinaExpendedora
    from expendedora.application.servicios import ServicioExpendedora
    repo = crear_repositorio_con_datos()
    maquina = MaquinaExpendedora(repo)
    return ServicioExpendedora(maquina)
